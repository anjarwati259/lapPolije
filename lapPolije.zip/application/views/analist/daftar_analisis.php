<section class="section">
  <div class="row align-items-top">
    <div class="col-lg-12">
      <div class="card">
        <h5 class="card-title"></h5>
          <div class="card-body">
            <table class="table" id="daftar_analisis-data">
                  <thead>
                    <tr>
                      <th scope="col">No</th>
                      <th scope="col">Kode Pesanan</th>
                      <th scope="col">Kode Sampel</th>
                      <th scope="col">Jenis Sample</th>
                      <th scope="col">Jenis Analisa</th>
                      <th scope="col">Metode Analisa</th>
                      <th scope="col">Status</th>
                      <!-- <th scope="col">Action</th> -->
                    </tr>
                  </thead>
                </table>
          </div>
      </div>
    </div>
  </div>
</section>
<?php include('analist_ajax.php'); ?>