<button type="submit">coba</button>
  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal-approved">Vertically centered</button>
<div class="modal fade" id="modal-approved" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Vertically Centered</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          Terima telah melakukan konfirmasi pada penawaran ini, selanjutnya silahkan lakukan pembayaran sebelum tanggal {3 hari}, jika melewati waktu pembayaran penawaran ini akan dibatalkan secara otomatis. Untuk tata cara pembayarn bisa klik link <a href="#">Disini.</a>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <a href="#" class="btn btn-primary">OK</a> 
        </div>
      </div>
    </div>
</div>