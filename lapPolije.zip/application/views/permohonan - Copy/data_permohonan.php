<section class="section">
  <div class="row align-items-top">
    <div class="col-lg-12">
      <div class="card">
        <h5 class="card-title"></h5>
          <div class="card-body">
            <table class="table" id="data_permohonan-data">
                  <thead>
                    <tr>
                      <th scope="col">No</th>
                      <th scope="col">Kode Registrasi</th>
                      <th scope="col">Kode Sampel</th>
                      <th scope="col">Tanggal Kirim</th>
                      <th scope="col">Jenis Sample</th>
                      <th scope="col">Nama Pemohon</th>
                      <th scope="col">Status</th>
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                </table>
          </div>
      </div>
    </div>
  </div>
</section>
<?php include('permohonan_ajax.php'); ?>